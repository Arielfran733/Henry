// ================================================================
// APP.JS — Toast, Modal, Lightbox, Liquid Glass Profile Popup
// ================================================================

const Toast = (() => {
  let wrap;
  function getWrap() { if (!wrap) { wrap = document.createElement('div'); wrap.className = 'toast-wrap'; document.body.appendChild(wrap); } return wrap; }
  function show(msg, type = 'info', duration = 3500) {
    const t = document.createElement('div'); t.className = `toast toast-${type}`;
    const icons = { success:'icon-check', error:'icon-x', info:'icon-activity' };
    t.innerHTML = `<span class="${icons[type]||'icon-activity'}"></span><span>${msg}</span>`;
    getWrap().appendChild(t);
    setTimeout(() => { t.style.animation = 'fadeOut 0.3s ease forwards'; t.addEventListener('animationend', () => t.remove()); }, duration);
  }
  return { show, success: m => show(m,'success'), error: m => show(m,'error'), info: m => show(m,'info') };
})();

async function api(action, data = {}, files = null) {
  const form = new FormData(); form.append('action', action);
  const csrf = document.querySelector('meta[name="csrf"]')?.content;
  if (csrf) form.append('csrf', csrf);
  for (const [k,v] of Object.entries(data)) form.append(k,v);
  if (files) for (const [k,f] of Object.entries(files)) form.append(k,f);
  try {
    const res = await fetch('api.php',{method:'POST',body:form});
    const text = await res.text(); let json;
    try { json = JSON.parse(text); } catch(e) { throw new Error('Server error.'); }
    if (json.error) throw new Error(json.error);
    return json;
  } catch(e) { throw e; }
}

function openLightbox(src) {
  const overlay = document.createElement('div'); overlay.className = 'lightbox-overlay';
  overlay.innerHTML = `<img src="${src}" class="lightbox-img" alt=""><button class="lightbox-close"><span class="icon-x"></span></button>`;
  overlay.addEventListener('click', e => { if (e.target === overlay || e.target.closest('.lightbox-close')) overlay.remove(); });
  document.body.appendChild(overlay);
  document.addEventListener('keydown', function esc(e) { if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', esc); } });
}
document.addEventListener('click', e => { const img = e.target.closest('[data-lightbox]'); if (img) openLightbox(img.dataset.lightbox || img.src); });

// Dropdown
document.addEventListener('click', e => {
  const trigger = e.target.closest('[data-dropdown-trigger]');
  const dropdowns = document.querySelectorAll('.user-dropdown');
  if (trigger) { e.stopPropagation(); const target = document.getElementById(trigger.dataset.dropdownTrigger); const isOpen = target?.classList.contains('show'); dropdowns.forEach(d => d.classList.remove('show')); if (!isOpen && target) target.classList.add('show'); }
  else { dropdowns.forEach(d => d.classList.remove('show')); }
});

function openModal(html) {
  const overlay = document.createElement('div'); overlay.className = 'modal-overlay';
  overlay.innerHTML = `<div class="modal">${html}</div>`;
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay); return overlay;
}
function closeModal() { document.querySelector('.modal-overlay')?.remove(); }

// ── LIQUID GLASS USER PROFILE POPUP ──
async function showUserProfile(userId) {
  try {
    const res = await fetch(`api.php?action=get_user_profile&user_id=${userId}`);
    const text = await res.text();
    let data; try { data = JSON.parse(text); } catch(e) { return; }
    if (data.error) { Toast.error(data.error); return; }
    const u = data.user;
    const currentUserId = window.CURRENT_USER_ID;
    const isMe = currentUserId && parseInt(currentUserId) === parseInt(userId);
    const roleColor = { admin:'#e8192c', premium:'#1877f2', user:'#555', new:'#444' }[u.role] || '#555';
    const roleName = { admin:'Admin', premium:'Premium', user: Lang.t('role_member'), new: Lang.t('role_new') }[u.role] || u.role;

    const tickHtml = (u.role === 'admin' || u.role === 'premium') ?
      `<div class="up-tick"><svg viewBox="0 0 22 22" fill="none"><circle cx="11" cy="11" r="11" fill="${roleColor}"/><path d="M6 11.5l3 3 6.5-7" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></div>` : '';

    const joinDate = new Date(u.created_at).toLocaleDateString(Lang.getLocale(),{year:'numeric',month:'short'});

    const overlay = document.createElement('div');
    overlay.className = 'glass-overlay';
    overlay.onclick = e => { if (e.target === overlay) overlay.remove(); };

    overlay.innerHTML = `<div class="glass-modal">
      <button class="gi-close" onclick="this.closest('.glass-overlay').remove()"><span class="icon-x"></span></button>
      <div class="up-banner"><div class="up-banner-grad" style="background:linear-gradient(135deg,${roleColor}33,${roleColor}11,#1a1a2e);"></div></div>
      <div class="up-avatar-wrap">
        <img src="${u.avatar||'assets/default-avatar.png'}" class="up-avatar" alt="">
        ${tickHtml}
      </div>
      <div class="up-body">
        <div class="up-username-tag">@${escHtml(u.username)}</div>
        <div class="up-name">${escHtml(u.username)}</div>
        ${u.bio ? `<div class="up-bio">${escHtml(u.bio)}</div>` : ''}
        <div class="up-actions">
          ${!isMe ? `
            <div class="up-action-btn" onclick="startDM(${u.id},'${escHtml(u.username)}');this.closest('.glass-overlay').remove();">
              <div class="up-icon"><span class="icon-chat"></span></div>${Lang.t('popup_message')}
            </div>
            <div class="up-action-btn" onclick="Toast.info(Lang.t('toast_coming_soon'))">
              <div class="up-icon">📞</div>${Lang.t('popup_voice')}
            </div>
            <div class="up-action-btn" onclick="Toast.info(Lang.t('toast_coming_soon'))">
              <div class="up-icon">🔒</div>${Lang.t('popup_secret')}
            </div>
            <div class="up-action-btn" onclick="reportUser(${u.id});this.closest('.glass-overlay').remove();">
              <div class="up-icon">⚠️</div>${Lang.t('popup_report')}
            </div>
          ` : `
            <a class="up-action-btn" href="index.php?page=account" style="text-decoration:none;">
              <div class="up-icon"><span class="icon-settings"></span></div>${Lang.t('popup_edit')}
            </a>
            <a class="up-action-btn" href="index.php?page=profile&id=${u.id}" style="text-decoration:none;">
              <div class="up-icon"><span class="icon-user"></span></div>${Lang.t('popup_profile')}
            </a>
          `}
        </div>
        <div class="up-stats">
          <div class="up-stat"><div class="up-stat-val">${u.product_count}</div><div class="up-stat-label">${Lang.t('popup_products')}</div></div>
          <div class="up-stat"><div class="up-stat-val">${joinDate}</div><div class="up-stat-label">${Lang.t('popup_joined')}</div></div>
          <div class="up-stat"><div class="up-stat-val">${roleName}</div><div class="up-stat-label">${Lang.t('popup_rank')}</div></div>
        </div>
        <div class="up-info-row">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="5" stroke="currentColor" stroke-width="1.3"/><path d="M7 4v3l2 1" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>
          ${Lang.t('popup_recently_online')}
        </div>
      </div>
    </div>`;
    document.body.appendChild(overlay);
  } catch(e) { Toast.error(Lang.t('toast_error_conn')); }
}

function getRoleBadgeHtml(role) {
  if (role==='admin') return `<span class="verified-tick admin-tick" title="Admin"><svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="12" fill="#e8192c"/><path d="M7 12.5l3.5 3.5 6.5-7" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>`;
  if (role==='premium') return `<span class="verified-tick premium-tick" title="Premium"><svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="12" fill="#1877f2"/><path d="M7 12.5l3.5 3.5 6.5-7" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>`;
  return '';
}
function getRoleBadgeSmall(role) {
  if (role==='admin') return `<span style="display:inline-flex;margin-left:2px;"><svg viewBox="0 0 16 16" fill="none" width="13" height="13"><circle cx="8" cy="8" r="8" fill="#e8192c"/><path d="M4.5 8.3l2.3 2.3 4.5-4.6" stroke="#fff" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg></span>`;
  if (role==='premium') return `<span style="display:inline-flex;margin-left:2px;"><svg viewBox="0 0 16 16" fill="none" width="13" height="13"><circle cx="8" cy="8" r="8" fill="#1877f2"/><path d="M4.5 8.3l2.3 2.3 4.5-4.6" stroke="#fff" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg></span>`;
  return '';
}

function escHtml(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
function formatDate(str) { return new Date(str).toLocaleDateString(Lang.getLocale(),{year:'numeric',month:'short'}); }

function reportUser(userId) {
  const html = `<div class="modal-title"><span class="icon-flag"></span> <span data-lang="report_title">Report</span></div><div class="form-group"><label class="form-label" data-lang="report_reason_label">Reason</label><textarea class="form-input" id="report-reason" data-lang-placeholder="report_reason_placeholder" placeholder="Describe the issue..."></textarea></div><div class="modal-actions"><button class="btn btn-ghost" onclick="closeModal()" data-lang="btn_cancel">Cancel</button><button class="btn btn-primary" onclick="submitReport(${userId})" data-lang="btn_send">Send</button></div>`;
  const overlay = openModal(html);
  // Apply lang to new modal content
  overlay.querySelectorAll('[data-lang]').forEach(el => { el.textContent = Lang.t(el.getAttribute('data-lang')); });
  overlay.querySelectorAll('[data-lang-placeholder]').forEach(el => { el.placeholder = Lang.t(el.getAttribute('data-lang-placeholder')); });
}
async function submitReport(userId) {
  const reason = document.getElementById('report-reason').value.trim();
  if (!reason) { Toast.error(Lang.t('toast_error_reason')); return; }
  try { await api('report_user',{target_user_id:userId,reason}); Toast.success(Lang.t('toast_report_sent')); closeModal(); } catch(e) { Toast.error(e.message); }
}

function startDM(userId, username) { window.location.href = `index.php?page=chat&dm=${userId}&name=${encodeURIComponent(username)}`; }

// Avatar popup in chat
document.addEventListener('click', e => {
  const existing = document.querySelector('.avatar-popup');
  const avatarEl = e.target.closest('[data-user-popup]');
  if (avatarEl) {
    e.stopPropagation(); if (existing) { existing.remove(); return; }
    const userId = avatarEl.dataset.userPopup;
    const username = avatarEl.dataset.username || '';
    const popup = document.createElement('div'); popup.className = 'avatar-popup';
    popup.innerHTML = `<button onclick="showUserProfile(${userId})"><span class="icon-user"></span> ${Lang.t('popup_profile')}</button><button onclick="startDM(${userId},'${escHtml(username)}')"><span class="icon-chat"></span> ${Lang.t('popup_message')}</button><button class="danger" onclick="reportUser(${userId})"><span class="icon-flag"></span> ${Lang.t('popup_report')}</button>`;
    const rect = avatarEl.getBoundingClientRect();
    popup.style.position = 'fixed'; popup.style.top = (rect.bottom+6)+'px'; popup.style.left = Math.min(rect.left,window.innerWidth-175)+'px';
    document.body.appendChild(popup);
  } else if (existing && !e.target.closest('.avatar-popup')) { existing.remove(); }
});

function handleFormSubmit(formEl, successMsg) {
  formEl.addEventListener('submit', async e => {
    e.preventDefault(); const btn = formEl.querySelector('[type=submit]'); const orig = btn?.innerHTML;
    if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner" style="width:16px;height:16px;margin:0;"></span>'; }
    try {
      const data = {}; const files = {};
      new FormData(formEl).forEach((val, key) => { if (val instanceof File) { if (val.size) files[key] = val; } else data[key] = val; });
      const action = formEl.dataset.action || data.action; delete data.action;
      const res = await api(action, data, Object.keys(files).length ? files : null);
      if (res.redirect) window.location.href = res.redirect;
      else if (successMsg) Toast.success(successMsg);
    } catch(e) { Toast.error(e.message); } finally { if (btn) { btn.disabled = false; btn.innerHTML = orig; } }
  });
}

document.addEventListener('input', e => {
  const el = e.target;
  if (el.tagName === 'TEXTAREA' && el.classList.contains('chat-textarea')) { el.style.height = 'auto'; el.style.height = Math.min(el.scrollHeight, 120) + 'px'; }
});

function debounce(fn, ms) { let t; return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); }; }

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('form[data-action]').forEach(f => { handleFormSubmit(f, f.dataset.success); });
  document.querySelectorAll('[data-preview-target]').forEach(input => {
    input.addEventListener('change', () => { const target = document.getElementById(input.dataset.previewTarget); const file = input.files[0]; if (!file||!target) return; const reader = new FileReader(); reader.onload = e => { target.src = e.target.result; target.style.display = 'block'; }; reader.readAsDataURL(file); });
  });
});
